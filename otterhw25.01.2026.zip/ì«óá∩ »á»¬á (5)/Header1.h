#pragma once

#include <iostream>

pow2(int a, int size, bool* fra) {
	int temp;
	int res = 1;
	for (int i=0, i < size, ++i) {
		temp = a;
		if (fra[i] == true) {
			for (int j, j < i+1, ++j) {
				temp = sqrt(temp);
				
			}
			res *= temp;

		}

	}

}